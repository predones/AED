﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace triangulo
{
    internal class triangulo
    {
        static void Main(string[] args)
        {
            Console.WriteLine("tipo de triangulo");
            tri p1 = new tri();

            Console.WriteLine("Digite o valor de A: ");
            p1.setA(float.Parse(Console.ReadLine()));
            Console.WriteLine("Digite o valor de B: ");
            p1.setB(float.Parse(Console.ReadLine()));
            Console.WriteLine("Digite o valor de C: ");
            p1.setC(float.Parse(Console.ReadLine()));

            Console.WriteLine("O valor de A é: " + p1.getA() + "\nO valor de B é: " + p1.getB() + "\nO valor de C é: " + p1.getC() + "\n\n") ;

            p1.Imprimirdados();

        } 
    }
}