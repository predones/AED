﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace triangulo
{
    internal class tri
    {
        private float a;
        private float b;
        private float c;

        public tri() { }

        public tri(float a, float b, float c)
        {
            this.a = a;
            this.b = b;
            this.c = c;
        }

        public void setA(float a)
        {
            this.a = a;
        }

        public float getA()
        {
            return this.a;
        }

        public void setB(float b)
        {
            this.b = b;
        }

        public float getB()
        {
            return this.b;
        }

        public void setC(float c)
        {

            this.c = c;
        }
        public float getC()
        {
            return this.c;
        }

        public void Imprimirdados()
        {
            if ((a == b) && (b == c))
            {
                Console.WriteLine("Triangulo Equilatero");
            }
            else if (a >= b + c)
            {
                Console.WriteLine("Não forma uma triangulo");
            }
            else if (a * a == (b * b) + (c * c))
            {
                Console.WriteLine("Triangulo Retangulo");
            }
            else if (a * a > (b * b) + (c * c))
            {
                Console.WriteLine("triangulo Obtusangulo");
            }
            else if (a * a < (b * b) + (c * c))
            {
                Console.WriteLine("Triangulo Acutangulo");
            }
            else
            {
                Console.WriteLine("Triangulo Isosceles");
            }
        }


    }
}
